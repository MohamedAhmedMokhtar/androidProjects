package com.example.android.newsapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ArrayList<HashMap<String, String>> newsList;
    ArrayList<String> listUrlValue = new ArrayList<>();
    private String TAG = MainActivity.class.getSimpleName();
    private ListView list_view;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        newsList = new ArrayList<>();
        list_view = (ListView) findViewById(R.id.list);

        new Getnews().execute();

        list_view.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {

                String targetUrl = listUrlValue.get(position);
                Intent specificUrl = new Intent(Intent.ACTION_VIEW);
                specificUrl.setData(Uri.parse(targetUrl));
                startActivity(specificUrl);
            }

        });
    }

    private class Getnews extends AsyncTask<Void, Void, Void> {
        protected Void doInBackground(Void... arg0) {
            HttpHandler sh = new HttpHandler();
            String url = "https://content.guardianapis.com/search?api-key=40e3f443-aeee-4d7c-b88f-6b5fcc56a06d";
            String jsonString = "";
            try {
                jsonString = sh.makeHttpRequest(createUrl(url));
            } catch (IOException e) {
                return null;
            }

            if (jsonString != null) {
                try {
                    JSONObject jsonObj = new JSONObject(jsonString);
                    JSONObject response = jsonObj.getJSONObject("response");
                    JSONArray newsResults = response.getJSONArray("results");

                    for (int i = 0; i < newsResults.length(); i++) {
                        JSONObject attribute = newsResults.getJSONObject(i);
                        String sectionName = attribute.getString("sectionName");
                        String webPublicationDate = attribute.getString("webPublicationDate");
                        String webTitle = attribute.getString("webTitle");
                        listUrlValue.add(attribute.getString("webUrl"));
                        HashMap<String, String> news = new HashMap<>();

                        news.put("name", sectionName);
                        news.put("date", webPublicationDate);
                        news.put("title", webTitle);
                        newsList.add(news);
                    }
                } catch (final JSONException e) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            Toast.makeText(getApplicationContext(), "check your internet connection", Toast.LENGTH_LONG).show();
                        }
                    });
                }

            } else {
                runOnUiThread(new Runnable() {
                    public void run() {
                        Toast.makeText(getApplicationContext(),
                                "Check your internet connection.",
                                Toast.LENGTH_LONG).show();
                    }
                });
            }

            return null;
        }









        private static final String newsUrl = "https://content.guardianapis.com/sections";

        public Loader<List<String>> onCreateLoader(int i, Bundle bundle) {

            SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this);

            // getString retrieves a String value from the preferences. The second parameter is the default value for this preference.
            String sectionName = sharedPrefs.getString(
                    getString(R.string.settings_section_key),
                    getString(R.string.settings_section_default_value));

            // parse breaks apart the URI string that's passed into its parameter

            Uri baseUri = Uri.parse(newsUrl);
 //https://content.guardianapis.com/sections?q=politics&api-key=40e3f443-aeee-4d7c-b88f-6b5fcc56a06d
            // buildUpon prepares the baseUri that we just parsed so we can add query parameters to it
            Uri.Builder uriBuilder = baseUri.buildUpon();

            // Append query parameter and its value. For example, the `format=geojson`
            uriBuilder.appendQueryParameter("q", sectionName);
            uriBuilder.appendQueryParameter("api-key", "40e3f443-aeee-4d7c-b88f-6b5fcc56a06d");

            // Return the completed uri `http://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&limit=10&minmag=minMagnitude&orderby=time
            return new NewsLoader(this, uriBuilder.toString());

        }






















        private URL createUrl(String stringUrl) {
            URL url = null;
            try {
                url = new URL(stringUrl);
            } catch (MalformedURLException exception) {
                return null;
            }
            return url;
        }

        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            ListAdapter adapter = new SimpleAdapter(MainActivity.this, newsList,
                    R.layout.news_list, new String[]{"name", "date", "title"},
                    new int[]{R.id.section_name, R.id.web_publication_date, R.id.web_title});
            list_view.setAdapter(adapter);
        }
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the Options Menu we specified in XML
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //Toast.makeText(this , id , Toast.LENGTH_SHORT).show();
        if (id == R.id.action_settings) {
            Intent settingsIntent = new Intent(this, SettingActivity.class);
            startActivity(settingsIntent);
            return true;


        }

        return super.onOptionsItemSelected(item);
    }
}
